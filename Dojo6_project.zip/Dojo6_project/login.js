function togglePasswordVisibility(toggle) {

    const input = toggle.parentNode.querySelector("#password");

    if (toggle.classList.contains('fa-eye-slash')) {

        toggle.classList.remove('fa-eye-slash');
        toggle.classList.add('fa-eye');

        input.setAttribute('type', 'password');

    } else {

        toggle.classList.add('fa-eye-slash');
        toggle.classList.remove('fa-eye');

        input.setAttribute('type', 'text');
    }

  }